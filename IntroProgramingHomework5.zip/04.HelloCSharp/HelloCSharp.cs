﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloCSharp
{
    class HelloCSharp
    {
        static void Main(string[] args)
        {  
            /* Problem 4. Hello World
             * • Create, compile and run a  “Hello C#”  console application.
             * • Ensure you have named the application well (e.g. “”HelloCSharp”).
             * You should submit the Visual Studio project holding the HelloCSharp class as part of your homework.
            */

            Console.WriteLine("Hello C#");
            Console.ReadLine();

        }
    }
}
