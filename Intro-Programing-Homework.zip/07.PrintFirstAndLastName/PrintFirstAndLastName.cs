﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintFirstAndLastName
{
    class PrintFirstAndLastName
    {
        static void Main(string[] args)
        {
            /* Problem 7. Print First and Last Name
             * • Create console application that prints your first and last name, each at a separate line.
             */

            Console.WriteLine("Zvezdelin");
            Console.WriteLine("Chucharkov");
            Console.ReadLine();

        }
    }
}
