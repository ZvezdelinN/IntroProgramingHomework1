﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrenrDateAndHour
{
    class CurrenrDateAndHour
    {
        static void Main(string[] args)
        {
            /* Problem 14. Current Date and Time
             * • Create a console application that prints the current date and time. Find out how in Internet.
             */

            Console.WriteLine(DateTime.Now);
            Console.ReadLine();
        }
    }
}
