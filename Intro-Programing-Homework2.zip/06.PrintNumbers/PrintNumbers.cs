﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintNumbers
{
    class PrintNumbers
    {
        static void Main(string[] args)
        {
            /* Problem 6. Print Numbers
             * • Write a program to print the numbers  1, 101 and 1001 , each at a separate line.
             * • Name the program correctly.
             * You should submit in your homework the Visual Studio project holding the source code of the PrintNumbers program.
             */

            Console.WriteLine("1");
            Console.WriteLine("101");
            Console.WriteLine("1001");
            Console.ReadLine();
        }
    }
}
